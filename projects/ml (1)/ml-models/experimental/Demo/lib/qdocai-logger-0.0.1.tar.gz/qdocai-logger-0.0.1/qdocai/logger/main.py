import logging


class QDocLogger():
    def __init__(self) -> None:
        # create console handler and set level to debug
        self.ch = logging.StreamHandler()

    def set_level(self, level, logger, logging) -> None:
        """
        function to set level of log
        """
        
        level_dict = {
            "INFO": logging.INFO,
            "DEBUG": logging.DEBUG,
            "WARNING": logging.WARNING,
            "ERROR": logging.ERROR,
            "CRITICAL": logging.CRITICAL
        }

        if level not in level_dict:
            logger.setLevel(logging.NOTSET)
        else:
            logger.setLevel(level_dict[level])

    def set_log(self, level=None, logger=None, message: str=None, base_log_params: dict={}) -> None:
        """
        function to set the log
        """
        
        log_level_dict = {
            "INFO": logger.info,
            "DEBUG": logger.debug,
            "WARNING": logger.warning,
            "ERROR": logger.error,
            "CRITICAL": logger.critical
        }

        if level not in log_level_dict:
            logger.info(message, extra=base_log_params)
        else:
            log_level_dict[level](message, extra=base_log_params)
    
    def ml_logger(self, level: str="NOTSET", ml_package: str=None, action: str=None, message: str=None, status_code: int=None, request_id: str=None, page_id: int=None) -> None:
        """
        This function does the logging of ML packages

        Logging Parameters
        - ml_package: "ml-models-pan"
        - timestamp: "2022-03-22 16:02:12"
        - action: "database connection"
        - message: "connection established"
        - status_code: 200
        - request_id: "a272be9e-41c1-4f40-af09-d8867f703378"
        - page_id: 1
        """
        
        base_log_params = {
            "ml_package": ml_package,
            "action": action,
            "status_code": status_code,
            "request_id": request_id,
            "page_id": page_id
        }

        # create logger
        logger = logging.getLogger('ML_LOG')
        self.set_level(level=level, logger=logger, logging=logging)

        if level == "WARNING":
            format = "%(levelname)s - %(ml_package)s - %(asctime)s - %(filename)s - %(lineno)d - %(action)s - %(message)s - %(status_code)s - %(request_id)s - %(page_id)s"
        elif level == "ERROR" or level == "CRITICAL" or level == "DEBUG":
            format = "%(levelname)s - %(ml_package)s - %(asctime)s - %(filename)s - %(funcName)s - %(lineno)d - %(action)s - %(message)s - %(status_code)s - %(request_id)s - %(page_id)s"
        else:
            format = "%(levelname)s - %(ml_package)s - %(asctime)s - %(action)s - %(message)s - %(status_code)s - %(request_id)s - %(page_id)s"

        # create formatter
        formatter = logging.Formatter(format)

        # add formatter to ch
        self.ch.setFormatter(formatter)

        # add ch to logger
        logger.addHandler(self.ch)

        self.set_log(level=level, logger=logger, message=message, base_log_params=base_log_params)

    def wrapper_logger(self, level: str="NOTSET", service_name: str=None, action: str=None, message: str=None, status_code: int=None, request_id: str=None, page_id: int=None) -> None:
        """
        This function does the logging of wrapper

        Logging Parameters
        - service_name: "image-prep-service"
        - timestamp: "2022-03-22 16:02:12"
        - action: "database connection"
        - message: "connection established"
        - status_code: 200
        - request_id: "a272be9e-41c1-4f40-af09-d8867f703378"
        - page_id: 1
        """
        
        base_log_params = {
            "service_name": service_name,
            "action": action,
            "status_code": status_code,
            "request_id": request_id,
            "page_id": page_id
        }

        # create logger
        logger = logging.getLogger('WRAPPER_LOG')
        self.set_level(level=level, logger=logger, logging=logging)

        if level == "WARNING":
            format = "%(levelname)s - %(service_name)s - %(asctime)s - %(filename)s - %(lineno)d - %(action)s - %(message)s - %(status_code)s - %(request_id)s - %(page_id)s"
        elif level == "ERROR" or level == "CRITICAL" or level == "DEBUG":
            format = "%(levelname)s - %(service_name)s - %(asctime)s - %(filename)s - %(funcName)s - %(lineno)d - %(action)s - %(message)s - %(status_code)s - %(request_id)s - %(page_id)s"
        else:
            format = "%(levelname)s - %(service_name)s - %(asctime)s - %(action)s - %(message)s - %(status_code)s - %(request_id)s - %(page_id)s"

        # create formatter
        formatter = logging.Formatter(format)

        # add formatter to ch
        self.ch.setFormatter(formatter)

        # add ch to logger
        logger.addHandler(self.ch)

        self.set_log(level=level, logger=logger, message=message, base_log_params=base_log_params)

    def connector_logger(self, level: str="NOTSET", connector_name: str=None, action: str=None, message: str=None, status_code: int=None, request_id: str=None, page_id: int=None) -> None:
        """
        This function does the logging of connector

        Logging Parameters
        - connector_name: "image-prep"
        - timestamp: "2022-03-22 16:02:12"
        - action: "database connection"
        - message: "connection established"
        - status_code: 200
        - request_id: "a272be9e-41c1-4f40-af09-d8867f703378"
        - page_id: 1
        """
        
        base_log_params = {
            "connector_name": connector_name,
            "action": action,
            "status_code": status_code,
            "request_id": request_id,
            "page_id": page_id
        }

        # create logger
        logger = logging.getLogger('CONNECTOR_LOG')
        self.set_level(level=level, logger=logger, logging=logging)

        if level == "WARNING":
            format = "%(levelname)s - %(connector_name)s - %(asctime)s - %(filename)s - %(lineno)d - %(action)s - %(message)s - %(status_code)s - %(request_id)s - %(page_id)s"
        elif level == "ERROR" or level == "CRITICAL" or level == "DEBUG":
            format = "%(levelname)s - %(connector_name)s - %(asctime)s - %(filename)s - %(funcName)s - %(lineno)d - %(action)s - %(message)s - %(status_code)s - %(request_id)s - %(page_id)s"
        else:
            format = "%(levelname)s - %(connector_name)s - %(asctime)s - %(action)s - %(message)s - %(status_code)s - %(request_id)s - %(page_id)s"

        # create formatter
        formatter = logging.Formatter(format)

        # add formatter to ch
        self.ch.setFormatter(formatter)

        # add ch to logger
        logger.addHandler(self.ch)

        self.set_log(level=level, logger=logger, message=message, base_log_params=base_log_params)
