
"""
Define name of the subpackage here.
"""


name="logger"

"""
Define Main classes to be used in the subpackage here.
"""

# from .types import ProcessTypes, InferenceProcess
# from .client import ClientController
from .main import QDocLogger