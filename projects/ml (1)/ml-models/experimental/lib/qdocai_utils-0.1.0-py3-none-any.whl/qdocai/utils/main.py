class DocAIException(Exception):
  def __init__(self, action: str=None, message: str=None, status_desc: str=None, status_code: int=200) -> None:
    self.action = action
    self.message = message
    self.status_desc = status_desc
    self.status_code = status_code

  def get_exception(self):
    return self.__dict__


class DocAIBase:
  def __init__(self, request_id: str=None, page_id: int=None) -> None:
    self.request_id = request_id
    self.page_id = page_id

  def get_request_params(self):
    return self.__dict__    